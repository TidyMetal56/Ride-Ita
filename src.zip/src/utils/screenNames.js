export default screen = { 
    main: 'Main Screen',
    start: 'Start Screen',
    signUp: 'SignUp Screen',
    home: 'Home Screen',
    settings: 'Settings Screen',
    history: 'History Screen',
    authenticated: 'Authenticated Screen',
    profile: 'Profile Screen'


};