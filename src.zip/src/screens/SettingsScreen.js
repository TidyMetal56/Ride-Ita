import React from 'react';
import { VStack, Text, Box, Avatar, HStack, Heading, Button, Image, Center } from "native-base";

const SettingsScreen = () => {
  return (
    <>
      <Center
        flex={1}
        height={'100%'}
        width={'100%'}
      >
      </Center>
    </>
  );
};

export default SettingsScreen;
